/* GUC Portal Overhaul — background service worker (MV3)
 * Responsibilities:
 *   - Seed sane defaults the first time the extension is installed.
 *   - Act as a tiny, central place for the default settings object so the
 *     popup and content script never disagree about shape.
 */

const DEFAULT_SETTINGS = {
  enabled: true,          // master on/off switch
  theme: "dark",          // dark | cyberpunk | glass | light
  animations: true,       // the "hell" animation layer
  intensity: "high",      // low | medium | high  (animation aggressiveness)
  customScrollbar: true,  // sleek webkit scrollbar
  fab: true,              // floating quick-action button
  roundCards: true,       // wrap legacy tables/forms in rounded surfaces
  fancyFonts: true,       // inject the display/body font stack
  deepRecolor: false      // EXPERIMENTAL: aggressively recolor generic containers
};

// Expose defaults to other parts of the extension via a simple message.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "GUC_GET_DEFAULTS") {
    sendResponse({ defaults: DEFAULT_SETTINGS });
  }
  return false;
});

chrome.runtime.onInstalled.addListener(async (details) => {
  try {
    const stored = await chrome.storage.local.get("gucSettings");
    const merged = { ...DEFAULT_SETTINGS, ...(stored.gucSettings || {}) };
    await chrome.storage.local.set({ gucSettings: merged });
    if (details.reason === "install") {
      // First run — nothing else needed; content script reads storage itself.
      console.log("[GUC Overhaul] Installed with defaults:", merged);
    }
  } catch (e) {
    console.warn("[GUC Overhaul] Could not seed defaults:", e);
  }
});
