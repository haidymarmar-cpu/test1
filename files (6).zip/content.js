/* ============================================================================
 * GUC Portal Overhaul — content.js
 * ----------------------------------------------------------------------------
 * Runs at document_start on *://apps.guc.edu.eg/*
 *
 * Strategy (read this if styling looks off):
 *   The portal is ASP.NET WebForms with auto-generated IDs we cannot know in
 *   advance. So this script works in THREE layers:
 *     1. UNIVERSAL  — theme variables, background, scrollbar, fonts, FAB,
 *                     <table> upgrades + grade badges. These need no selectors
 *                     and work on any page.
 *     2. CONFIGURED — structural pieces (navbar / sidebar / profile / shortcuts)
 *                     driven by the SELECTORS object below. EDIT THESE to match
 *                     your DOM (right-click element -> Inspect -> copy a stable
 *                     class or id). Multiple comma-separated guesses are allowed.
 *     3. HEURISTIC  — if a configured selector matches nothing, we fall back to
 *                     conservative text/structure heuristics so you still get a
 *                     reasonable result before tuning selectors.
 * ==========================================================================*/

(() => {
  "use strict";

  /* ----------------------------------------------------------------------- *
   * 1. EDIT-ME: selectors for the structural chrome of the portal.
   *    Prefilled with sensible guesses for GUC SIS + common ASP.NET patterns.
   * ----------------------------------------------------------------------- */
  const SELECTORS = {
    // The top bar (logo, title "Student Portal - SIS", "Hello, GUC\\user").
    navbar: 'header, #header, .navbar, .top-nav, .topbar, [class*="header"]',

    // The left vertical navigation menu container.
    sidebar: '#menu, #sidebar, .sidebar, .side-menu, nav.menu, [class*="sidebar"], [id*="menu"]',

    // Individual clickable items inside the sidebar.
    sidebarItem: 'a, .menu-item, li > a',

    // The main content region (right of the sidebar).
    mainContent: '#content, #main, main, .content, .main-content, [class*="content"]',

    // The student profile / ID card panel.
    profileCard: '[id*="profile"], .profile, .profile-card, .student-card',

    // The "SHORTCUTS" panel that holds the quick-link grid.
    shortcutsContainer: '[id*="shortcut"], .shortcuts, .quick-links',

    // Individual shortcut tiles (External Libraries, ASMT, CMS, ...).
    shortcutCard: 'a'
  };

  /* Fallback default settings (mirror background.js). Used only if storage is
   * empty before the service worker seeds it. */
  const DEFAULTS = {
    enabled: true, theme: "dark", animations: true, intensity: "high",
    customScrollbar: true, fab: true, roundCards: true, fancyFonts: true,
    deepRecolor: false
  };

  const ROOT = document.documentElement;
  let settings = { ...DEFAULTS };
  let observer = null;
  let staggerCounter = 0;

  /* ----------------------------------------------------------------------- *
   * Helpers
   * ----------------------------------------------------------------------- */
  const $$ = (sel, ctx = document) => {
    try { return Array.from(ctx.querySelectorAll(sel)); }
    catch { return []; }
  };
  const firstMatch = (sel, ctx = document) => {
    try { return ctx.querySelector(sel); } catch { return null; }
  };
  const debounce = (fn, ms) => {
    let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  };
  const has = (el, cls) => el && el.classList && el.classList.contains(cls);
  const mark = (el, cls) => { if (el && el.classList && !has(el, cls)) el.classList.add(cls); };

  const setStagger = (el) => {
    if (!el || el.dataset.gucStagger) return;
    el.dataset.gucStagger = "1";
    // Wrap the index so the cascade stays snappy and AJAX/postback content
    // injected late in a session never waits multiple seconds to appear.
    el.style.setProperty("--guc-i", String((staggerCounter++) % 18));
    mark(el, "guc-reveal");
  };

  /* ----------------------------------------------------------------------- *
   * Apply settings -> root attributes/classes. Safe to call repeatedly.
   * Done at document_start so theming applies before paint (no flash).
   * ----------------------------------------------------------------------- */
  function applySettings() {
    ROOT.classList.toggle("guc-on", !!settings.enabled);
    ROOT.setAttribute("data-guc-theme", settings.theme || "dark");
    ROOT.setAttribute("data-guc-anim", settings.animations ? "on" : "off");
    ROOT.setAttribute("data-guc-intensity", settings.intensity || "high");
    ROOT.setAttribute("data-guc-scrollbar", settings.customScrollbar ? "on" : "off");
    ROOT.setAttribute("data-guc-round", settings.roundCards ? "on" : "off");
    ROOT.setAttribute("data-guc-deeprecolor", settings.deepRecolor ? "on" : "off");
    ROOT.setAttribute("data-guc-fonts", settings.fancyFonts ? "on" : "off");
  }

  /* ----------------------------------------------------------------------- *
   * Fonts — best-effort. The <link> is subject to the PAGE's CSP; if the page
   * blocks it the CSS fallback stack still gives a clean look.
   * ----------------------------------------------------------------------- */
  function ensureFonts() {
    if (!settings.fancyFonts) return;
    if (document.getElementById("guc-fonts")) return;
    const add = (href, id) => {
      const l = document.createElement("link");
      l.rel = "stylesheet"; l.href = href; l.id = id; l.crossOrigin = "anonymous";
      (document.head || ROOT).appendChild(l);
    };
    try {
      const pre = document.createElement("link");
      pre.rel = "preconnect"; pre.href = "https://fonts.gstatic.com"; pre.crossOrigin = "anonymous";
      (document.head || ROOT).appendChild(pre);
      add("https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Outfit:wght@300;400;500;600&family=Space+Mono:wght@400;700&family=Orbitron:wght@600;800&display=swap", "guc-fonts");
    } catch (_) { /* CSP blocked — fallbacks handle it */ }
  }

  /* ----------------------------------------------------------------------- *
   * Structural tagging (configured + heuristic fallback)
   * ----------------------------------------------------------------------- */
  function tagStructure() {
    // Navbar
    let nav = firstMatch(SELECTORS.navbar);
    if (nav) mark(nav, "guc-navbar");

    // Sidebar + items
    let side = firstMatch(SELECTORS.sidebar);
    if (!side) {
      // Heuristic: a vertical-ish container with several links and a "Search" box.
      side = $$("div,nav,aside").find(el => {
        const links = el.querySelectorAll("a").length;
        return links >= 6 && el.getBoundingClientRect().width < 420 &&
               el.getBoundingClientRect().height > 300;
      }) || null;
    }
    if (side) {
      mark(side, "guc-sidebar");
      $$(SELECTORS.sidebarItem, side).forEach(a => { mark(a, "guc-nav-item"); setStagger(a); });
    }

    // Main content
    let main = firstMatch(SELECTORS.mainContent);
    if (main) mark(main, "guc-main");

    enhanceProfile(main || document);
    enhanceShortcuts(main || document);
  }

  /* ----------------------------------------------------------------------- *
   * Profile card -> floating ID badge
   * ----------------------------------------------------------------------- */
  function enhanceProfile(scope) {
    let card = firstMatch(SELECTORS.profileCard, scope);
    if (!card) {
      // Heuristic: find the label "Full Name" and climb to a card-like ancestor.
      const labelEl = $$("*, td, th, span, div, label", scope).find(el => {
        const t = (el.textContent || "").trim().toLowerCase();
        return (t === "full name" || t === "full name:") && el.children.length === 0;
      });
      if (labelEl) {
        let p = labelEl;
        for (let i = 0; i < 6 && p && p.parentElement; i++) {
          p = p.parentElement;
          const txt = (p.textContent || "").toLowerCase();
          if (txt.includes("uniq") || txt.includes("guc mail") || txt.includes("faculty")) {
            card = p; break;
          }
        }
      }
    }
    if (!card || has(card, "guc-profile")) return;
    mark(card, "guc-profile");
    setStagger(card);

    // Tag label/value rows so the gradient row-sweep applies.
    const rows = $$("tr", card).length ? $$("tr", card)
               : $$(":scope > div, :scope > * > div", card);
    rows.forEach(r => {
      const t = (r.textContent || "").trim();
      if (t.length && t.length < 200) mark(r, "guc-profile-row");
    });
  }

  /* ----------------------------------------------------------------------- *
   * Shortcuts -> floating card grid
   * ----------------------------------------------------------------------- */
  function enhanceShortcuts(scope) {
    let box = firstMatch(SELECTORS.shortcutsContainer, scope);
    if (!box) {
      // Heuristic: a panel whose heading text is "SHORTCUTS".
      const heading = $$("*", scope).find(el => {
        const t = (el.textContent || "").trim().toUpperCase();
        return t === "SHORTCUTS" && el.children.length === 0;
      });
      if (heading) {
        let p = heading;
        for (let i = 0; i < 5 && p && p.parentElement; i++) {
          p = p.parentElement;
          if (p.querySelectorAll("a").length >= 3) { box = p; break; }
        }
      }
    }
    if (!box || has(box, "guc-shortcuts")) return;
    mark(box, "guc-shortcuts");
    $$(SELECTORS.shortcutCard, box).forEach(a => {
      if (!(a.textContent || "").trim()) return;
      mark(a, "guc-shortcut-card");
      setStagger(a);
    });
  }

  /* ----------------------------------------------------------------------- *
   * Tables -> modern, sortable, sticky-header tables with grade badges
   * ----------------------------------------------------------------------- */
  function enhanceTables(scope = document) {
    $$("table", scope).forEach(table => {
      if (has(table, "guc-table") || table.closest(".guc-no-touch")) return;
      // Skip tiny layout tables (WebForms loves nesting them) and our own UI.
      const rows = table.rows ? table.rows.length : 0;
      const cells = table.querySelectorAll("td,th").length;
      if (rows < 2 || cells < 4) return;
      if (table.closest(".guc-navbar, .guc-sidebar, .guc-fab-wrap")) return;

      mark(table, "guc-table");
      setStagger(table);

      // Wrap for rounded surface + horizontal scroll on small screens.
      if (settings.roundCards && !table.parentElement.classList.contains("guc-table-wrap")) {
        const wrap = document.createElement("div");
        wrap.className = "guc-table-wrap guc-reveal";
        table.parentNode.insertBefore(wrap, table);
        wrap.appendChild(table);
      }

      // Header detection.
      let headerRow = table.tHead ? table.tHead.rows[0] : table.rows[0];
      if (headerRow) {
        mark(headerRow, "guc-thead-row");
        Array.from(headerRow.cells).forEach((th, idx) => {
          mark(th, "guc-th");
          if (!th.dataset.gucSortable) {
            th.dataset.gucSortable = "1";
            th.title = "Click to sort";
            th.addEventListener("click", () => sortTable(table, idx, th));
          }
        });
      }

      // Grade badges across body cells.
      badgeGrades(table, headerRow);
    });
  }

  function badgeGrades(table, headerRow) {
    // Columns whose header marks them as non-grades (credits, codes, ids,
    // hours, counts, dates) are skipped so plain numbers there stay plain.
    const skipCols = new Set();
    if (headerRow) {
      Array.from(headerRow.cells).forEach((h, i) => {
        const t = (h.textContent || "").toLowerCase();
        if (/credit|ects|hour|\bcode\b|\bid\b|\bno\.?\b|count|level|\byear\b|semester|date/.test(t)) {
          skipCols.add(i);
        }
      });
    }
    const bodyRows = Array.from(table.rows).filter(r => r !== headerRow);
    bodyRows.forEach(r => {
      Array.from(r.cells).forEach(cell => {
        if (skipCols.has(cell.cellIndex)) return;
        if (cell.querySelector(".guc-grade")) return;
        const raw = (cell.textContent || "").trim();
        const cls = gradeClass(raw);
        if (cls) {
          cell.innerHTML = `<span class="guc-grade ${cls}">${raw}</span>`;
        }
      });
    });
  }

  /* Map a cell's text to a grade severity class.
   * Supports letter grades (A/B/C/D/F +/-) AND the German scale GUC uses
   * (1.0 best -> 5.0 fail). Returns null if it isn't a grade-looking value. */
  function gradeClass(raw) {
    if (!raw) return null;
    const s = raw.replace(/\s+/g, "");
    // Letter grades
    const letter = /^([A-F])([+-])?$/i.exec(s);
    if (letter) {
      const L = letter[1].toUpperCase();
      return ({ A: "guc-g-excellent", B: "guc-g-good", C: "guc-g-ok",
                D: "guc-g-warn", E: "guc-g-bad", F: "guc-g-bad" })[L] || null;
    }
    // German numeric scale 0.7 .. 5.0 — GUC always writes one decimal place
    // (1.0, 1.7, 2.3 ...). Requiring the decimal avoids painting bare integers
    // from a Credits / ECTS / count column as if they were grades.
    const num = /^(\d[.,]\d)$/.exec(s);
    if (num) {
      const v = parseFloat(num[1].replace(",", "."));
      if (v < 0.5 || v > 5.0) return null; // out of grade range -> not a grade
      if (v <= 1.3) return "guc-g-excellent";
      if (v <= 1.7) return "guc-g-vgood";
      if (v <= 2.3) return "guc-g-good";
      if (v <= 3.0) return "guc-g-ok";
      if (v <= 4.0) return "guc-g-warn";
      return "guc-g-bad";
    }
    // Words
    const w = s.toLowerCase();
    if (["pass", "passed", "active", "completed", "done"].includes(w)) return "guc-g-excellent";
    if (["fail", "failed", "inactive", "withdrawn"].includes(w)) return "guc-g-bad";
    if (["pending", "inprogress", "in-progress"].includes(w)) return "guc-g-warn";
    return null;
  }

  /* Simple, numeric-aware column sort that toggles asc/desc. */
  function sortTable(table, colIdx, th) {
    const headerRow = th.parentElement;
    const bodyRows = Array.from(table.rows).filter(r => r !== headerRow);
    const dir = th.dataset.gucDir === "asc" ? "desc" : "asc";
    // reset siblings
    Array.from(headerRow.cells).forEach(c => { delete c.dataset.gucDir; c.classList.remove("guc-sorted-asc", "guc-sorted-desc"); });
    th.dataset.gucDir = dir;
    th.classList.add(dir === "asc" ? "guc-sorted-asc" : "guc-sorted-desc");

    const val = (row) => {
      const c = row.cells[colIdx];
      return c ? (c.textContent || "").trim() : "";
    };
    const num = (s) => {
      const m = s.replace(/[^0-9.,-]/g, "").replace(",", ".");
      const f = parseFloat(m);
      return isNaN(f) ? null : f;
    };
    bodyRows.sort((a, b) => {
      const av = val(a), bv = val(b);
      const an = num(av), bn = num(bv);
      let r;
      if (an !== null && bn !== null) r = an - bn;
      else r = av.localeCompare(bv, undefined, { numeric: true, sensitivity: "base" });
      return dir === "asc" ? r : -r;
    });
    const parent = bodyRows[0] ? bodyRows[0].parentElement : table.tBodies[0] || table;
    bodyRows.forEach((r, i) => { r.classList.add("guc-resort"); parent.appendChild(r);
      r.addEventListener("animationend", () => r.classList.remove("guc-resort"), { once: true }); });
  }

  /* ----------------------------------------------------------------------- *
   * Floating Action Button (quick access to CMS + E-Mail)
   * ----------------------------------------------------------------------- */
  function buildFAB() {
    if (!settings.fab) { const ex = document.getElementById("guc-fab-wrap"); if (ex) ex.remove(); return; }
    if (document.getElementById("guc-fab-wrap")) return;
    if (!document.body) return;

    const wrap = document.createElement("div");
    wrap.id = "guc-fab-wrap";
    wrap.className = "guc-fab-wrap";
    wrap.innerHTML = `
      <div class="guc-fab-actions">
        <a class="guc-fab-action" href="https://cms.guc.edu.eg/" target="_blank" rel="noopener" data-tip="CMS">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 10h18M8 18v2m8-2v2"/></svg>
        </a>
        <a class="guc-fab-action" href="https://mail.guc.edu.eg/" target="_blank" rel="noopener" data-tip="GUC E-Mail">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
        </a>
        <button class="guc-fab-action" id="guc-fab-top" data-tip="Back to top" type="button">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>
        </button>
      </div>
      <button class="guc-fab-main" id="guc-fab-main" type="button" aria-label="Quick actions">
        <svg class="guc-fab-icon" viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
      </button>`;
    document.body.appendChild(wrap);

    document.getElementById("guc-fab-main").addEventListener("click", () => {
      wrap.classList.toggle("guc-fab-open");
    });
    document.getElementById("guc-fab-top").addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
      wrap.classList.remove("guc-fab-open");
    });
    document.addEventListener("click", (e) => {
      if (!wrap.contains(e.target)) wrap.classList.remove("guc-fab-open");
    });
    // Click ripple on interactive bits.
    attachRipples(wrap);
  }

  /* ----------------------------------------------------------------------- *
   * Ripple effect on clicks (sidebar items, shortcut cards, FAB, buttons)
   * ----------------------------------------------------------------------- */
  function attachRipples(scope = document) {
    const targets = $$(".guc-nav-item, .guc-shortcut-card, .guc-fab-action, .guc-fab-main, .guc-th", scope);
    targets.forEach(el => {
      if (el.dataset.gucRipple) return;
      el.dataset.gucRipple = "1";
      el.addEventListener("click", (e) => {
        if (ROOT.getAttribute("data-guc-anim") !== "on") return;
        const rect = el.getBoundingClientRect();
        const r = document.createElement("span");
        r.className = "guc-ripple";
        const size = Math.max(rect.width, rect.height);
        r.style.width = r.style.height = size + "px";
        r.style.left = (e.clientX - rect.left - size / 2) + "px";
        r.style.top = (e.clientY - rect.top - size / 2) + "px";
        el.appendChild(r);
        r.addEventListener("animationend", () => r.remove(), { once: true });
      });
    });
  }

  /* ----------------------------------------------------------------------- *
   * Page routing — apply a body-level class so CSS can target page types.
   * ----------------------------------------------------------------------- */
  function routePage() {
    const url = window.location.href.toLowerCase();
    const flags = [];
    if (url.includes("index.aspx") || url.endsWith("/student_ext/")) flags.push("guc-page-dashboard");
    if (/grade|grading|transcript/.test(url)) flags.push("guc-page-grades");
    if (/eval/.test(url)) flags.push("guc-page-eval");
    if (/exam|seat/.test(url)) flags.push("guc-page-exam");
    if (/schedul|timetable|course/.test(url)) flags.push("guc-page-schedule");
    if (/financ|payment|invoice/.test(url)) flags.push("guc-page-finance");
    if (/attend/.test(url)) flags.push("guc-page-attendance");
    if (document.body) flags.forEach(f => mark(document.body, f));
  }

  /* ----------------------------------------------------------------------- *
   * The main enhancement pass (idempotent).
   * ----------------------------------------------------------------------- */
  function enhanceAll() {
    if (!settings.enabled || !document.body) return;
    mark(document.body, "guc-body");
    routePage();
    tagStructure();
    enhanceTables(document);
    buildFAB();
    attachRipples(document);
  }

  /* ----------------------------------------------------------------------- *
   * MutationObserver — re-run for AJAX/postback-injected content.
   * ----------------------------------------------------------------------- */
  const reEnhance = debounce(() => { try { enhanceAll(); } catch (e) { /* noop */ } }, 180);

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        if (m.addedNodes && m.addedNodes.length) { reEnhance(); break; }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  /* ----------------------------------------------------------------------- *
   * Boot
   * ----------------------------------------------------------------------- */
  function boot() {
    ensureFonts();
    enhanceAll();
    startObserver();
  }

  // Apply theming attributes immediately (document_start) to avoid a flash,
  // using optimistic defaults; reconcile once storage resolves.
  applySettings();

  chrome.storage.local.get("gucSettings").then((res) => {
    settings = { ...DEFAULTS, ...(res.gucSettings || {}) };
    applySettings();
    if (document.body) boot();
    else document.addEventListener("DOMContentLoaded", boot, { once: true });
  }).catch(() => {
    if (document.body) boot();
    else document.addEventListener("DOMContentLoaded", boot, { once: true });
  });

  // Live updates when the popup changes a setting.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.gucSettings) return;
    settings = { ...DEFAULTS, ...changes.gucSettings.newValue };
    applySettings();
    ensureFonts();
    // Re-run so toggles like FAB / round cards take effect instantly.
    if (document.body) enhanceAll();
  });
})();
