/* GUC Portal Overhaul — popup.js
 * Reads/writes chrome.storage.local.gucSettings. The content script listens to
 * storage changes and updates the open portal tab live (no reload needed for
 * most toggles). */

const DEFAULTS = {
  enabled: true, theme: "dark", animations: true, intensity: "high",
  customScrollbar: true, fab: true, roundCards: true, fancyFonts: true,
  deepRecolor: false
};

const TOGGLES = ["enabled", "animations", "customScrollbar", "fab", "roundCards", "fancyFonts", "deepRecolor"];

let state = { ...DEFAULTS };

const $ = (id) => document.getElementById(id);

function persist() {
  chrome.storage.local.set({ gucSettings: state });
}

function render() {
  // Checkboxes
  TOGGLES.forEach((k) => { const el = $(k); if (el) el.checked = !!state[k]; });

  // Theme cards
  document.querySelectorAll(".theme").forEach((card) => {
    card.classList.toggle("active", card.dataset.theme === state.theme);
  });

  // Intensity segmented
  document.querySelectorAll("#intensity button").forEach((b) => {
    b.classList.toggle("on", b.dataset.v === state.intensity);
  });

  // Dim everything when master is off
  $("controls").classList.toggle("body-dim", !state.enabled);
}

function init() {
  chrome.storage.local.get("gucSettings").then((res) => {
    state = { ...DEFAULTS, ...(res.gucSettings || {}) };
    render();
  });

  // Toggle switches
  TOGGLES.forEach((k) => {
    const el = $(k);
    if (!el) return;
    el.addEventListener("change", () => {
      state[k] = el.checked;
      persist();
      if (k === "enabled") render(); // dim/undim
    });
  });

  // Theme selection
  document.querySelectorAll(".theme").forEach((card) => {
    card.addEventListener("click", () => {
      state.theme = card.dataset.theme;
      persist();
      render();
    });
  });

  // Intensity
  document.querySelectorAll("#intensity button").forEach((b) => {
    b.addEventListener("click", () => {
      state.intensity = b.dataset.v;
      persist();
      render();
    });
  });
}

document.addEventListener("DOMContentLoaded", init);
